import { useState } from "react";

const ProductCard = () => {
  const [details, setDetails] = useState(false);

  return (
    <div className="p-5 rounded-xl shadow-md">
      <h2 className="text-xl font-bold">Toyota Land Cruiser</h2>

      <button
        onClick={() => setDetails(!details)}
        className="mt-3 bg-blue-700 text-white px-4 py-2 rounded"
      >
        Details
      </button>

      {details && <p className="mt-3">4WD - B6 Armored - 7 Seats</p>}
    </div>
  );
};

export default ProductCard;
