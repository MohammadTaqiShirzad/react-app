import React, { useState } from "react";

const Counter = () => {
  const [count, setCount] = useState(0);
  return (
    <div className=" bg-gray-200 px-20 py-4 flex flex-col items-center">
      <h1 className="text-5xl font-black">Counter</h1>
      <p className="text-lg mt-4 text-gray-600">
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nostrum non
        recusandae, velit doloremque cumque, eveniet, alias voluptatibus
        aspernatur iure quisquam rem. Quisquam, doloremque.
      </p>
      <div className="flex items-center gap-4 mt-8">
        <h2 className="text-3xl font-bold">{count}</h2>

        <div>
          <button
            className="bg-blue-500 text-white px-4 py-2 rounded"
            onClick={() => setCount(count + 1)}
          >
            +
          </button>

          <button
            className="bg-red-500 text-white px-4 py-2 rounded"
            onClick={() => setCount(count - 1)}
          >
            -
          </button>
        </div>
      </div>
    </div>
  );
};

export default Counter;
