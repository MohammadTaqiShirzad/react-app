import { useState } from "react";

const ShowMessage = () => {
  const [show, setShow] = useState(false);

  return (
    <div className="bg-gray-200 px-20 py-4 flex flex-col items-center">
      <button onClick={() => setShow(!show)}>Show / Hide</button>

      {show && <p>Hello React!</p>}
    </div>
  );
};

export default ShowMessage;
