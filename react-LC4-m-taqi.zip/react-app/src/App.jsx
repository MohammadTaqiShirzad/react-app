import Footer from "./common/Footer";
import Navbar from "./common/Navbar";
import Counter from "./components/Counter";
import LikeButton from "./components/LikeButton";
import NameInput from "./components/NameInput";
import ProductCard from "./components/ProductCard";
import ShowMessage from "./components/ShowMessage";

function App() {
  return (
    <div className="min-h-screen bg-slate-100">
      <Navbar />
      <div className="flex flex-wrap justify-center gap-4 p-4">
        <Counter />
        <ProductCard />
        <LikeButton />
        <NameInput />
        <ShowMessage />
      </div>
      <Footer />
    </div>
  );
}
