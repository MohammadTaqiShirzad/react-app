import Footer from "./common/Footer";
import Navbar from "./common/Navbar";
import Card from "./components/Card";

function App() {
  return (
    <div className="min-h-screen bg-slate-100">
      <Navbar />

      <main className="grid grid-cols-1 gap-6 p-6 md:grid-cols-3">
        <Card
          title="Web Development"
          description="Build useful websites."
          imageUrl="/web.jpg"
        />

        <Card
          title="Graphic Design"
          description="Create clear visual designs."
          imageUrl="/design.jpg"
        />

        <Card
          title="Digital Skills"
          description="Use computers confidently."
          imageUrl="/skills.jpg"
        />
      </main>

      <Footer />
    </div>
  );
}
export default App;
